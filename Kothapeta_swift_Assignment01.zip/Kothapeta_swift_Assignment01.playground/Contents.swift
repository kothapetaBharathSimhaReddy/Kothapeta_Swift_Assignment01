import UIKit
 
//*******Questions******//
 
// 1. In which year was the first version of the Swift programming language introduced? Explain about type safety and type inference in Swift?
print("The first version of Swift was introduced in 2014, Type safety in Swift ensures that variables are only used in ways that are consistent with their type, which helps prevent type-related errors. Type inference allows Swift to automatically deduce the type of a variable or constant based on the value assigned to it, making the code more concise and readable.")
print("-----------------------------------------------------------------------------------------------------------------------------------------------")
// End of question 1
 
 
 
 
 
// 2. Declare a constant 'pi' of type Double and assign it the value 3.14. Calculate the volume of Cylinder with a diameter of 15 and height of 12.0 units. using the formula: Volume =  pi * radius*radius*height. Print the obtained result as shown in sample output.
 
let pi: Double = 3.14
let diameter: Double = 15
let radius = diameter / 2
let height: Double = 12.0
let volume = pi * radius * radius * height
print("The volume of the cylinder is \(volume) units.")
print("-----------------------------------------------------------------------------------------------------------------------------------------------")
// End of question 2
 
 
 
 
 
// 3. Declare a variable with a value of 102.9°F, convert it to Celsius, and round it to two decimal places. Then, print the result in the following format using a single print statement. [Replace the **** with converted celsius value.]
// Fahrenheit: 102.9 F and Celsius: **** C
let fahrenheit: Double = 102.9
let celsius = (fahrenheit - 32) * 5 / 9
let roundedCelsius = String(format: "%.2f", celsius)
print("Fahrenheit: \(fahrenheit) F and Celsius: \(roundedCelsius) C")
print("-----------------------------------------------------------------------------------------------------------------------------------------------")
// End of question 3
 
 
 
 
 
 
// 4. Write four aspects about your career aspirations using four print statements and display the first three aspects on first line, and the fourth aspect on the next line.
print("I aspire to be a proficient software engineer, work on innovative technologies, and contribute to impactful projects.", terminator:",")
print("I also aim to continually improve my problem-solving skills and collaborate effectively with teams.", terminator: ",")
print("Lastly, I hope to mentor others and share my knowledge in the field.")
print("My ultimate goal is to lead projects that drive technological advancements.")
print("-----------------------------------------------------------------------------------------------------------------------------------------------")
// End of question 4
 
 
 
 
 
 
// 5. Display the following using a single print statement.
// "Swift is a safe and fast programming language that combines the best in modern language thinking with wisdom from diverse open source.It is a powerful and intuitive programming language for iOS, iPadOS, macOS, tvOS, and watchOS.
//   Writing Swift code is interactive and fun, the syntax is concise yet expressive, and Swift includes modern features   developers love.
//Its an industrial quality programming language. The compiler is optimized for performance and the language is optimized for development.
//The Swift programming offers safety and speed. It provides type inference, pattern matching.
//   Swift code is safe by design and produces software that runs lightning-fast."
print("Swift is a safe and fast programming language that combines the best in modern language thinking with wisdom from diverse open source. It is a powerful and intuitive programming language for iOS, iPadOS, macOS, tvOS, and watchOS.", "Writing Swift code is interactive and fun, the syntax is concise yet expressive, and Swift includes modern features developers love.", "It's an industrial quality programming language. The compiler is optimized for performance and the language is optimized for development.", "The Swift programming offers safety and speed. It provides type inference, pattern matching.", "Swift code is safe by design and produces software that runs lightning-fast.",separator:"\n")
print("-----------------------------------------------------------------------------------------------------------------------------------------------")
// End of question 5
 
 
 
 
 
 
 
// 6. Declare a variable called 'number1' and assign it a three-digit integer. Next, declare another variable called 'number2' and assign it a different three-digit integer. Then, create a third variable named 'product' to store the result of multiplying 'number1' and 'number2'. Write code to calculate the number of digits in the product and print the result. For example, if the number1 is 987, and number2 is 118 the output should be: 'The product of two numbers is 116466 and it contains  6 digits.' Take any two numbers of your choice.
let number1 = 345
let number2 = 678
let product = number1 * number2
let numberOfDigits = String(product).count
print("The product of two numbers \(number1) and \(number2) is \(product) and it contains \(numberOfDigits) digits.")
print("-----------------------------------------------------------------------------------------------------------------------------------------------")
// End of question 6
 
 
 
 
 
 
// 7. Create a variable with value "Welcome to iOS Mobile Computing Class!!".Print the total number of characters in the above text excluding spaces and then print each character separated by "+". Exlcude the spaces.

let text = "Welcome to iOS Mobile Computing Class!!"
var filteredText = ""
var characterCount = 0

for char in text {
    if char != " " {
        filteredText.append(char)
        characterCount += 1
    }
}

var charactersSeparatedByPlus = ""
for i in 0..<filteredText.count {
    let index = filteredText.index(filteredText.startIndex, offsetBy: i)
    charactersSeparatedByPlus.append(filteredText[index])
    if i < filteredText.count - 1 {
        charactersSeparatedByPlus.append("+")
    }
}

print("The number of characters excluding spaces is \(characterCount)")
print("The modified text is:")
print(charactersSeparatedByPlus)

print("-----------------------------------------------------------------------------------------------------------------------------------------------")
// End of question 7
 
 
 
 
 
 
 
// 8.An object begins its motion with an initial velocity of 8.75 m/s and accelerates at a constant rate of 4.25 m/s² along a straight path. Its final velocity at the end of the motion is 12.5 m/s. Calculate the displacement of the object and print the result in the specified format using print statements.[Replace the **** with converted Displacement value.] Use the formula:    displacement = ((final velocity*final velocity) - (initial velocity*initial velocity))/(2*acceleration)
 
 
let initialVelocity: Double = 8.75
let finalVelocity: Double = 12.5
let acceleration: Double = 4.25
let displacement = ((finalVelocity * finalVelocity) - (initialVelocity * initialVelocity)) / (2 * acceleration)
 
// Print results in the specified format
print("Initial Velocity: \(initialVelocity) m/s")
print("Final Velocity: \(finalVelocity) m/s")
print("Displacement: \(displacement) m")
print("-----------------------------------------------------------------------------------------------------------------------------------------------")
// End of question 8
